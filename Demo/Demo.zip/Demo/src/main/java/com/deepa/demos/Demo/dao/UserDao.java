package com.deepa.demos.Demo.dao;

import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.stereotype.Repository;

import com.deepa.demos.Demo.model.User;

@Repository
public class UserDao implements interfaceDao {

	ArrayList<User> users=new ArrayList<User>();
	Iterator ir=users.iterator();
	
	@Override
	public ArrayList getUserById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList getAllUser() {
		// TODO Auto-generated method stub
		return users;
	}

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		 users.add(user);
		return user;
		
	}

	@Override
	public ArrayList<User> updateUser(User user) {
		for(int i=0;i<users.size();i++) {
			if(users.get(i).getId()==user.getId()) {
				users.get(i).setName(user.getName());
				
			}
		}

		// TODO Auto-generated method stub
		return users;
	}
	public ArrayList<User> delete(int id){
//		while(ir.hasNext()) {
//			
//		}
		for(int i=0;i<users.size();i++) {
			if(users.get(i).getId()==id) {
				users.remove(i);
				
			}
		}
		return users;
		
	}

}
