package com.deepa.demos.Demo.controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deepa.demos.Demo.dao.UserDao;
import com.deepa.demos.Demo.model.User;

@RestController
@RequestMapping("/userapp")
public class UserController {

	@Autowired
	UserDao dao;
	
	@RequestMapping("/users/test")
	public String testUser() {
		return "User Demo";
	}
	@RequestMapping("/users/{id}")
	public User getUser(@PathVariable int id) {
		User user=new User();
		user.setName("username");
		user.setId(1);
		return user;
	}
	@PostMapping("/users")
	public User createUser(@RequestBody User user) {
		return dao.createUser(user);
	}
	@GetMapping("/getusers")
	public ArrayList<User> getAllUser(){
		return dao.getAllUser();
	}
	@DeleteMapping("/delete/{id}")
	 public ArrayList<User> delete(@PathVariable int id){
		return dao.delete(id);
		 
	 }
	@PutMapping("/put")
	public ArrayList<User> update(@RequestBody User user){
		return (ArrayList<User>) dao.updateUser(user);
		
	}
	
}
