package com.deepa.demos.Demo.dao;

import java.util.ArrayList;

import com.deepa.demos.Demo.model.User;

public interface interfaceDao {
public ArrayList getUserById(int id) ;
public ArrayList getAllUser();
public User createUser(User user);
public ArrayList<User> updateUser(User user);

}
