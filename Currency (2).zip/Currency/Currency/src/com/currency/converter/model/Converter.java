/**
 * 
 */
package com.currency.converter.model;

/**
 * @author abrige
 *
 */
public interface Converter {
	
	public void currencyConverter(float amount);

}
