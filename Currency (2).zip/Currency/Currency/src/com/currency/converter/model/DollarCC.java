/**
 * 
 */
package com.currency.converter.model;

import org.springframework.stereotype.Component;

/**
 * @author abrige
 *
 */
//@Component("a1")
public class DollarCC implements Converter {

	@Override
	public void currencyConverter(float amount) {
		// TODO Auto-generated method stub
		System.out.println("Amount in US Dollar is :"+(amount*0.014));
		
	}

}
