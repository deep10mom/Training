/**
 * 
 */
package com.currency.converter.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


     
/**
 * @author abrige
 *
 */  
public class TestConverter {

	/**
	 * @param args
	 */
	public static void main( String[] args) {
		// TODO Auto-generated method stub
		 
		ApplicationContext context =new ClassPathXmlApplicationContext ("currency.xml"); 
		User u1=(User)context.getBean("user1");
		u1.converterCurrency(5000);

	}

}
