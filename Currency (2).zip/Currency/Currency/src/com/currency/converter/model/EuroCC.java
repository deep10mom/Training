/**
 * 
 */
package com.currency.converter.model;

import org.springframework.stereotype.Component;

/**
 * @author abrige
 *
 */
@Component("a2")
public class EuroCC implements Converter {

	@Override
	public void currencyConverter(float amount) {
		// TODO Auto-generated method stub

		System.out.println("Amount in Euro is:"+(amount*0.013));
	}

}
