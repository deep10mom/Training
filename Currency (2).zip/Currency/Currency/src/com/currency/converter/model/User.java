/**
 * 
 */
package com.currency.converter.model;


import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author abrige
 *
 */
@Component("user1")
public class User implements InitializingBean, DisposableBean {
	
	@Autowired
	Converter converter;

	public User(Converter converter) {
		super();
		this.converter = converter;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void converterCurrency(float money)
	{
		converter.currencyConverter(money);
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		
	}

	

}
