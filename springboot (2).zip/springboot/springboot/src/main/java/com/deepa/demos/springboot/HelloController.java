/**
 * 
 */
package com.deepa.demos.springboot;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author abridge
 *
 */
//RestController
@Controller
@RequestMapping("/hello")
public class HelloController {
	
	@RequestMapping("/hi")
	public @ResponseBody  String sayHello()
	{
		return "Hello Boot";
	}
	
	@RequestMapping("/hiii")
	public @ResponseBody String sayHi()
	{
		return "Hi boot";
	}
	
}

